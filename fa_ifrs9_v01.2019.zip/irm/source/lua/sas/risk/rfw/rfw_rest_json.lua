--[[
/* Copyright (C) 2015 SAS Institute Inc. Cary, NC, USA */

/*!
\file

\brief   Module provides JSON parsing functionality for interacting with the IRM REST API

\details 
   The following functions are available:
   - parseJSONFile(<filename or fileref>): Parse a JSON file and returns a Lua table
   - irmRestPlain(<filename or fileref>, output): Parse a JSON file and returns an output SAS table (Assumes a plain/flat JSON structure)

\ingroup commonAnalytics
 
\author  SAS Institute Inc.

\date    2015

*/

]]


local filesys = require 'sas.risk.utils.filesys'
local stringutils = require 'sas.risk.utils.stringutils'
local args = require 'sas.risk.utils.args'
local errors = require 'sas.risk.utils.errors'
local sas_msg = require 'sas.risk.utils.sas_msg'
local tableutils = require 'sas.risk.utils.tableutils'
local json = require 'sas.risk.utils.json'
local json_utils = require 'sas.risk.irm.irm_rest_parser'

json.strictTypes = true

local M = {}

M.rfwRestPlain = json_utils.jsonRestPlain

rfwRestProcessDef = function(filename, outputProcess, outputTransition)
   local jsonTable = json_utils.parseJSONFile(filename)
   local resultProcess = {}
   local resultTransition = {}
   if jsonTable ~= nil then
      -- Check if there are any process definitions
      if jsonTable.items ~= nil then
         -- Loop through each process definition
         for j, pdef in pairs(jsonTable.items) do

            -- Loop through each node of this process definition
            for k, node in pairs(pdef.nodes) do
               
               local nodeRow = {}
              
               -- Get basic properties of the current process definition
               nodeRow.ProcessId = pdef.id
               nodeRow.ProcessName = pdef.name
               nodeRow.ProcessDescription = pdef.description
               nodeRow.createdByUser = pdef.createdByUser
               nodeRow.createdTimestamp = pdef.createdTimestamp
               nodeRow.lastModified = pdef.lastModified
               nodeRow.updatedByUser = pdef.updatedByUser
               nodeRow.transitoryCapabilitiesExist = pdef.transitoryCapabilitiesExist
               
               -- Get the node properties
               nodeRow.Id = node.processNodeId
               nodeRow.Role = node.userRole
               nodeRow.Type = ""
               if node.nodeType == 0 then
                  nodeRow.Type = "S"
               elseif node.nodeType == 1 then
                  nodeRow.Type = "E"
               end
               nodeRow.Label = node.nodeLabel
               nodeRow.Description = node.description
               nodeRow.Task = node.nodeImpl
               nodeRow.TaskParameters = node.nodeParms
               nodeRow.DueDays = node.dueInDays
               nodeRow.Mode = node.mode
               nodeRow.Notification = node.notificationType
               nodeRow.NotificationParameters = ""
               if node.notificationParms ~= nil then
                  nodeRow.NotificationParameters = node.notificationParms
               end
               
               -- Add current row to the resultProcess table
               nodeRow = json_utils.processBoolean(nodeRow)
               table.insert(resultProcess, nodeRow)
               
               -- Get the transition properties
               for n, transition in pairs(node.predecessorNodes) do
                  local transitionRow = {}
                  transitionRow.ProcessName = pdef.name
                  transitionRow.From = transition.sourceId
                  transitionRow.To = transition.targetId
                  transitionRow.Sync = math.max(transition.syncGroup, 0)
                  transitionRow.Expression = ""
                  if transition.expression ~= nil then
                     transitionRow.Expression = transition.expression
                  end
                  
                  -- Add current row to the resultTransition table
                  transitionRow = json_utils.processBoolean(transitionRow)
                  table.insert(resultTransition, transitionRow)
               end
               
            end
         end
      end
      
      
      for k, v in pairs(resultProcess[1]) do
         print(k, v)
      end
      sas.write_ds(resultProcess, outputProcess)
      sas.write_ds(resultTransition, outputTransition)
   end
end;
M.rfwRestProcessDef = rfwRestProcessDef

rfwRestHierarchyCatDef = function(filename, outputProcess)
   local jsonTable = json_utils.parseJSONFile(filename)
   local resultProcess = {}
   if jsonTable ~= nil then
      -- Check if there are any category definitions
      if next(jsonTable.items) ~= nil then
         -- Loop through each category definition
         for j, pdef in pairs(jsonTable.items) do

               local nodeRow = {}
              
               -- Get basic properties of the current category definition
               nodeRow.categoryKey = pdef.id
               nodeRow.categoryName = pdef.name
               nodeRow.categoryCode = pdef.categoryCode
               nodeRow.categoryDescription = pdef.description
               nodeRow.createdByUser = pdef.createdByUser
               nodeRow.createdTimestamp = pdef.createdTimestamp
               nodeRow.lastModified = pdef.lastModified
               nodeRow.updatedByUser = pdef.updatedByUser
                                           
               -- Add current row to the resultProcess table
               nodeRow = json_utils.processBoolean(nodeRow)
               table.insert(resultProcess, nodeRow)              
         end
         
         for k, v in pairs(resultProcess[1]) do
            print(k, v)
         end
         
      end

      sas.write_ds(resultProcess, outputProcess)
 
   end
end;
M.rfwRestHierarchyCatDef = rfwRestHierarchyCatDef

rfwRestHierarchyDef = function(filename, outputProcess)
   local jsonTable = json_utils.parseJSONFile(filename)
   local resultProcess = {}
   if jsonTable ~= nil then
      -- Check if there are any hierarchy definitions
      if jsonTable.items ~= nil then
         -- Loop through each hierarchy definition
         for j, pdef in pairs(jsonTable.items) do

          
               local nodeRow = {}
              
               -- Get basic properties of the current hierarchy definition
               nodeRow.hierarchyKey = pdef.hierarchyKey
               nodeRow.hierarchyName = pdef.name
               nodeRow.hierarchyCode = pdef.code
               nodeRow.description = pdef.description
               nodeRow.createdByUser = pdef.createdByUser
               nodeRow.createdTime = pdef.createdTime
               nodeRow.lastModified = pdef.lastModified
               nodeRow.updatedByUser = pdef.updatedByUser
                                           
               -- Add current row to the resultProcess table
               nodeRow = json_utils.processBoolean(nodeRow)
               table.insert(resultProcess, nodeRow)              
         end
      end
      
      
      for k, v in pairs(resultProcess[1]) do
         print(k, v)
      end
      sas.write_ds(resultProcess, outputProcess)
   end
end;
M.rfwRestHierarchyDef = rfwRestHierarchyDef

rfwRestCreateCategory = function(filename, output)
   local jsonTable = parseJSONFile(filename)
   if jsonTable ~= nil then
      result = {}

      -- Process category info
      row = {}
      row.categoryKey = jsonTable.categoryKey
      row.categoryName = jsonTable.name
      row.categoryCode = jsonTable.categoryCode
      row.description = jsonTable.description
      table.insert(result, row)
      
      sas.write_ds(result, output)
   end
end;
M.rfwRestCreateCategory = rfwRestCreateCategory


rfwRestHierarchyKey = function(filename, output)
   local jsonTable = parseJSONFile(filename)
   if jsonTable ~= nil then
      result = {}

      -- Process hierarchy status
      row = {}
      row.hierarchyKey = jsonTable.hierarchyKey
      row.hierarchyName = jsonTable.name
      row.description = jsonTable.description
      row.version = jsonTable.version
      table.insert(result, row)
      
      sas.write_ds(result, output)
   end
end;
M.rfwRestHierarchyKey = rfwRestHierarchyKey

rfwRestModelDef = function(filename, outputProcess)
   local jsonTable = json_utils.parseJSONFile(filename)
   local resultProcess = {}
   if jsonTable ~= nil then
      -- Check if there are any model definitions
      if jsonTable.items ~= nil then
         -- Loop through each model definition
         for j, pdef in pairs(jsonTable.items) do

          
               local nodeRow = {}
              
               -- Get basic properties of the current model definition
               nodeRow.modelKey = pdef.id
               nodeRow.modelId = pdef.modelId
               nodeRow.modelName = pdef.name
                                           
               -- Add current row to the resultProcess table
               nodeRow = json_utils.processBoolean(nodeRow)
               table.insert(resultProcess, nodeRow)              
         end
      end
      
      
      for k, v in pairs(resultProcess[1]) do
         print(k, v)
      end
      sas.write_ds(resultProcess, outputProcess)
   end
end;
M.rfwRestModelDef = rfwRestModelDef

return M