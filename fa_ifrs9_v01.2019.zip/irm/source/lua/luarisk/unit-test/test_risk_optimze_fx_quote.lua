local graph = require "luastl.graph"

local risk =require "luarisk.risk"

------------------------------------------------------------------------
--FX_Quote[BASE_CURRENCY][QUOTE_CURRENCY] = BASE_CURRENCY/QUOTE_CURRENCY
local FX_Quote_Data={}
FX_Quote_Data["EUR"] = {}
FX_Quote_Data["USD"] = {}
FX_Quote_Data["JPY"] = {}
FX_Quote_Data["AUD"] = {}
FX_Quote_Data["GBP"] = {}
FX_Quote_Data["CAD"] = {}
FX_Quote_Data["CHF"] = {}
FX_Quote_Data["NZD"] = {}

--EUR/USD bid quote
FX_Quote_Data["EUR"]["USD"] = 1.3628
--reciprocal of EUR/USD ask quote
FX_Quote_Data["USD"]["EUR"] = 1/1.3630

FX_Quote_Data["USD"]["JPY"] = 102.57
FX_Quote_Data["JPY"]["USD"] = 1/102.59


FX_Quote_Data["GBP"]["USD"] = 1.6781
FX_Quote_Data["USD"]["GBP"] = 1/1.6784

FX_Quote_Data["USD"]["CHF"] = 0.8944
FX_Quote_Data["CHF"]["USD"] = 1/0.8974

FX_Quote_Data["EUR"]["GBP"] = 0.8120
FX_Quote_Data["GBP"]["EUR"] = 1/0.8122

FX_Quote_Data["EUR"]["JPY"] = 139.79
FX_Quote_Data["JPY"]["EUR"] = 1/139.81

FX_Quote_Data["EUR"]["CHF"] = 1.2191
FX_Quote_Data["CHF"]["EUR"] = 1/1.2194

FX_Quote_Data["AUD"]["USD"] = 0.9323
FX_Quote_Data["USD"]["AUD"] = 1/0.9323

FX_Quote_Data["USD"]["CAD"] = 1.0939
FX_Quote_Data["CAD"]["USD"] = 1/1.0942

FX_Quote_Data["NZD"]["USD"] = 0.8497
FX_Quote_Data["USD"]["NZD"] = 1/0.8500

------------------------------------------------------------
--
-- Bellman-Ford optimized quote unit test
--
------------------------------------------------------------

local graphFX = graph.NewGraph()

graphFX.setGraphMatrix(FX_Quote_Data)

local FXQuote = risk.newFXQuote()

FXQuote.setFXQuoteGraph(graphFX)

FXQuote.convertCompleteFXQuote()

local REPORT_CURRENCY = "GBP"

local flag, opt_quotes_graph, predecessorSet = FXQuote.getOptimizedFXQuote(REPORT_CURRENCY)

local base_currency, quote_currency, quote, pre_currency

print("-----------------------------------------------------")
print("Optimized FX Quote test:")
print("-----------------------------------------------------")

print("Arbitrage opportunity doesn't exist: "..tostring(flag))

for base_currency, quote_currency, quote in opt_quotes_graph.allEdges() do
  print(base_currency.."/"..quote_currency..":"..quote)
end

local predecessors = predecessorSet.getElementValue(REPORT_CURRENCY)

for quote_currency, pre_currency in pairs(predecessors) do
  print(pre_currency.."-->"..quote_currency)
end

assert(flag == true)
assert(opt_quotes_graph.getWeight(REPORT_CURRENCY, "USD") == FX_Quote_Data["GBP"]["USD"])
assert(opt_quotes_graph.getWeight(REPORT_CURRENCY, "EUR") == FX_Quote_Data["GBP"]["EUR"])
assert(math.abs(opt_quotes_graph.getWeight(REPORT_CURRENCY, "CHF") - FX_Quote_Data["GBP"]["EUR"] * FX_Quote_Data["EUR"]["CHF"]) < 1E-10 == true)
assert(math.abs(opt_quotes_graph.getWeight(REPORT_CURRENCY, "JPY") - FX_Quote_Data["GBP"]["USD"] * FX_Quote_Data["USD"]["JPY"]) < 1E-10 == true)
assert(math.abs(opt_quotes_graph.getWeight(REPORT_CURRENCY, "NZD") - FX_Quote_Data["GBP"]["USD"] * FX_Quote_Data["USD"]["NZD"]) < 1E-10 == true)
assert(math.abs(opt_quotes_graph.getWeight(REPORT_CURRENCY, "CAD") - FX_Quote_Data["GBP"]["USD"] * FX_Quote_Data["USD"]["CAD"]) < 1E-10 == true)
assert(math.abs(opt_quotes_graph.getWeight(REPORT_CURRENCY, "AUD") - FX_Quote_Data["GBP"]["USD"] * FX_Quote_Data["USD"]["AUD"]) < 1E-10 == true)


------------------------------------------------------------
--
-- BFS quote unit test
--
------------------------------------------------------------
print("\n-----------------------------------------------------")
print("BFS FX Quote test:")
print("-----------------------------------------------------")

local bfs_quotes_graph, predecessorSet = FXQuote.getBFSFXQuote(REPORT_CURRENCY)

for base_currency, quote_currency, quote in bfs_quotes_graph.allEdges() do
  print(base_currency.."/"..quote_currency..":"..quote)
end

predecessors = predecessorSet.getElementValue(REPORT_CURRENCY)

for quote_currency, pre_currency in pairs(predecessors) do
  print(pre_currency.."-->"..quote_currency)
end

assert(bfs_quotes_graph.getWeight(REPORT_CURRENCY,"USD") == FX_Quote_Data["GBP"]["USD"])
assert(bfs_quotes_graph.getWeight(REPORT_CURRENCY,"EUR") == FX_Quote_Data["GBP"]["EUR"])

------------------------------------------------------------
--
-- all pairs optimized quote unit test
-- 
------------------------------------------------------------
--get all pairs optimized quote
local flag, opt_quotes_graph, _ = FXQuote.getOptimizedFXQuote(nil, 1E-10)

print("\n-----------------------------------------------------")
print("All pairs optimized FX Quote test:")
print("-----------------------------------------------------")
print("Arbitrage opportunity doesn't exist: "..tostring(flag))
for base_currency, quote_currency, quote in opt_quotes_graph.allEdges() do
  print(base_currency.."/"..quote_currency..":"..quote)
end
-- arbitrage opportunities doesn't exist
assert(flag == true)
assert(math.abs(opt_quotes_graph.getWeight("GBP", "USD") - FX_Quote_Data["GBP"]["USD"]) < 1E-10 == true)
assert(math.abs(opt_quotes_graph.getWeight("GBP", "EUR") - FX_Quote_Data["GBP"]["EUR"]) < 1E-10 == true)
assert(math.abs(opt_quotes_graph.getWeight("GBP", "CHF") - FX_Quote_Data["GBP"]["EUR"] * FX_Quote_Data["EUR"]["CHF"]) < 1E-10 == true)
assert(math.abs(opt_quotes_graph.getWeight("GBP", "JPY") - FX_Quote_Data["GBP"]["USD"] * FX_Quote_Data["USD"]["JPY"]) < 1E-10 == true)
assert(math.abs(opt_quotes_graph.getWeight("GBP", "NZD") - FX_Quote_Data["GBP"]["USD"] * FX_Quote_Data["USD"]["NZD"]) < 1E-10 == true)
assert(math.abs(opt_quotes_graph.getWeight("GBP", "CAD") - FX_Quote_Data["GBP"]["USD"] * FX_Quote_Data["USD"]["CAD"]) < 1E-10 == true)
assert(math.abs(opt_quotes_graph.getWeight("GBP", "AUD") - FX_Quote_Data["GBP"]["USD"] * FX_Quote_Data["USD"]["AUD"]) < 1E-10 == true)

------------------------------------------------------------
--
-- all pairs BFS quote unit test
-- 
------------------------------------------------------------
--get all pairs optimized quote
local bfs_quotes_graph, _ = FXQuote.getBFSFXQuote()

print("\n-----------------------------------------------------")
print("All pairs BFS FX Quote test:")
print("-----------------------------------------------------")
for base_currency, quote_currency, quote in bfs_quotes_graph.allEdges() do
  print(base_currency.."/"..quote_currency..":"..quote)
end

assert(math.abs(bfs_quotes_graph.getWeight("GBP","USD") - FX_Quote_Data["GBP"]["USD"]) < 1E-10 == true)
assert(math.abs(bfs_quotes_graph.getWeight("GBP","EUR") - FX_Quote_Data["GBP"]["EUR"]) < 1E-10 == true)


------------------------------------------------------------
--
-- Bellman-Ford optimized quote with rounding error
-- unit test 
--
------------------------------------------------------------
local FX_Quote_Data={}
FX_Quote_Data["EUR"] = {}
FX_Quote_Data["USD"] = {}
FX_Quote_Data["JPY"] = {}
FX_Quote_Data["AUD"] = {}
FX_Quote_Data["GBP"] = {}
FX_Quote_Data["CAD"] = {}
FX_Quote_Data["CHF"] = {}
FX_Quote_Data["NZD"] = {}

--EUR/USD bid quote
FX_Quote_Data["EUR"]["USD"] = 1.3628
--reciprocal of EUR/USD ask quote
FX_Quote_Data["USD"]["EUR"] = 1/1.3630

FX_Quote_Data["USD"]["JPY"] = 102.57
FX_Quote_Data["JPY"]["USD"] = 1/102.59


FX_Quote_Data["GBP"]["USD"] = 1.6781
FX_Quote_Data["USD"]["GBP"] = 1/1.6784

FX_Quote_Data["USD"]["CHF"] = 0.8944
FX_Quote_Data["CHF"]["USD"] = 1/0.8974

FX_Quote_Data["EUR"]["GBP"] = 0.8120
FX_Quote_Data["GBP"]["EUR"] = 1/0.8122

FX_Quote_Data["EUR"]["JPY"] = 139.79
FX_Quote_Data["JPY"]["EUR"] = 1/139.81

FX_Quote_Data["EUR"]["CHF"] = 1.2191
FX_Quote_Data["CHF"]["EUR"] = 1/1.2194

-- rounding error caused by -log transformation function
-- eg, run the following in Lua 5.2 in LAX 3.14.8-200.fc20.x86_64.
-- Although in theory the following assertion should be true, due to rounding error it is not exactly zero.
-- assert(-1 * math.log(10) -1 *math.log(1/10) == 0)
--stdin:1: assertion failed!
-- 
-- Without rounding error as input, there would be a negative cycles between AUD and USD.
-- We tested this by providing rounding error 1E-10
FX_Quote_Data["AUD"]["USD"] = 10
FX_Quote_Data["USD"]["AUD"] = 1/10

FX_Quote_Data["USD"]["CAD"] = 1.0939
FX_Quote_Data["CAD"]["USD"] = 1/1.0942

FX_Quote_Data["NZD"]["USD"] = 0.8497
FX_Quote_Data["USD"]["NZD"] = 1/0.8500

local graphFX = graph.NewGraph()

graphFX.setGraphMatrix(FX_Quote_Data)

local FXQuote = risk.newFXQuote()

FXQuote.setFXQuoteGraph(graphFX)

FXQuote.convertCompleteFXQuote()

local REPORT_CURRENCY = "GBP"

local flag, opt_quotes_graph, predecessorSet = FXQuote.getOptimizedFXQuote(REPORT_CURRENCY, 1E-10)

local base_currency, quote_currency, quote, pre_currency

print("-----------------------------------------------------")
print("Optimized FX Quote test with rounding error:")
print("-----------------------------------------------------")

print("Arbitrage opportunity doesn't exist: "..tostring(flag))

for base_currency, quote_currency, quote in opt_quotes_graph.allEdges() do
  print(base_currency.."/"..quote_currency..":"..quote)
end

local predecessors = predecessorSet.getElementValue(REPORT_CURRENCY)

for quote_currency, pre_currency in pairs(predecessors) do
  print(pre_currency.."-->"..quote_currency)
end

assert(flag == true)
assert(math.abs(opt_quotes_graph.getWeight(REPORT_CURRENCY, "USD") - FX_Quote_Data["GBP"]["USD"]) < 1E-10 == true)
assert(math.abs(opt_quotes_graph.getWeight(REPORT_CURRENCY, "EUR") - FX_Quote_Data["GBP"]["EUR"]) < 1E-10 == true)
assert(math.abs(opt_quotes_graph.getWeight(REPORT_CURRENCY, "CHF") - FX_Quote_Data["GBP"]["EUR"] * FX_Quote_Data["EUR"]["CHF"]) < 1E-10 == true)
assert(math.abs(opt_quotes_graph.getWeight(REPORT_CURRENCY, "JPY") - FX_Quote_Data["GBP"]["USD"] * FX_Quote_Data["USD"]["JPY"]) < 1E-10 == true)
assert(math.abs(opt_quotes_graph.getWeight(REPORT_CURRENCY, "NZD") - FX_Quote_Data["GBP"]["USD"] * FX_Quote_Data["USD"]["NZD"]) < 1E-10 == true)
assert(math.abs(opt_quotes_graph.getWeight(REPORT_CURRENCY, "CAD") - FX_Quote_Data["GBP"]["USD"] * FX_Quote_Data["USD"]["CAD"]) < 1E-10 == true)
assert(math.abs(opt_quotes_graph.getWeight(REPORT_CURRENCY, "AUD") - FX_Quote_Data["GBP"]["USD"] * FX_Quote_Data["USD"]["AUD"]) < 1E-10 == true)


------------------------------------------------------------
--
-- case 2
-- 
------------------------------------------------------------
local FX_Quote_Data={}
FX_Quote_Data["CAD"] = {}
FX_Quote_Data["CZK"] = {}
FX_Quote_Data["SEK"] = {}
FX_Quote_Data["CHF"] = {}
FX_Quote_Data["AUD"] = {}
FX_Quote_Data["DKK"] = {}
FX_Quote_Data["SKK"] = {}
FX_Quote_Data["USD"] = {}
FX_Quote_Data["HRK"] = {}
FX_Quote_Data["PLN"] = {}
FX_Quote_Data["GBP"] = {}
FX_Quote_Data["NOK"] = {}
FX_Quote_Data["HUF"] = {}
FX_Quote_Data["EUR"] = {}
FX_Quote_Data["JPY"] = {}

FX_Quote_Data["CAD"]["HRK"]=4.8904059991
FX_Quote_Data["CZK"]["HRK"]=0.241789
FX_Quote_Data["SEK"]["USD"]=0.1246960534
FX_Quote_Data["SEK"]["EUR"]=0.1209459565
FX_Quote_Data["SEK"]["NOK"]=0.9326618168
FX_Quote_Data["SEK"]["GBP"]=0.0751049592
FX_Quote_Data["SEK"]["CHF"]=0.1706834164
FX_Quote_Data["SEK"]["HRK"]=0.777426
FX_Quote_Data["SEK"]["DKK"]=0.7869058861
FX_Quote_Data["SEK"]["JPY"]=14.071228559
FX_Quote_Data["CHF"]["EUR"]=0.7085866531
FX_Quote_Data["CHF"]["HRK"]=4.6631130003
FX_Quote_Data["CHF"]["SEK"]=5.8588
FX_Quote_Data["AUD"]["HRK"]=4.5613409995
FX_Quote_Data["DKK"]["EUR"]=0.1343611062
FX_Quote_Data["DKK"]["HRK"]=0.977675
FX_Quote_Data["DKK"]["SEK"]=1.2708
FX_Quote_Data["SKK"]["HRK"]=0.186501
FX_Quote_Data["USD"]["HRK"]=6.0471240013
FX_Quote_Data["USD"]["EUR"]=0.782105
FX_Quote_Data["USD"]["SEK"]=8.0195
FX_Quote_Data["HRK"]["CZK"]=4.135837445
FX_Quote_Data["HRK"]["CAD"]=0.2044820001
FX_Quote_Data["HRK"]["CHF"]=0.2144490172
FX_Quote_Data["HRK"]["SEK"]=1.286296059
FX_Quote_Data["HRK"]["DKK"]=1.0228347866
FX_Quote_Data["HRK"]["SKK"]=5.3619015448
FX_Quote_Data["HRK"]["USD"]=0.1653678674
FX_Quote_Data["HRK"]["EUR"]=0.1370982148
FX_Quote_Data["HRK"]["PLN"]=0.5592237527
FX_Quote_Data["HRK"]["GBP"]=0.0948446255
FX_Quote_Data["HRK"]["NOK"]=1.0846939916
FX_Quote_Data["HRK"]["HUF"]=0.3358769293
FX_Quote_Data["HRK"]["AUD"]=0.2192337736
FX_Quote_Data["HRK"]["JPY"]=17.699115044
FX_Quote_Data["PLN"]["HRK"]=1.788193
FX_Quote_Data["GBP"]["EUR"]=1.16611
FX_Quote_Data["GBP"]["HRK"]=10.543560004
FX_Quote_Data["GBP"]["SEK"]=13.3147
FX_Quote_Data["NOK"]["EUR"]=0.1275492308
FX_Quote_Data["NOK"]["HRK"]=0.921919
FX_Quote_Data["NOK"]["SEK"]=1.0722
FX_Quote_Data["HUF"]["HRK"]=2.9772810002
FX_Quote_Data["EUR"]["SEK"]=8.2681557031
FX_Quote_Data["EUR"]["CHF"]=1.41126
FX_Quote_Data["EUR"]["DKK"]=7.44263
FX_Quote_Data["EUR"]["USD"]=1.2786006994
FX_Quote_Data["EUR"]["EUR"]=1
FX_Quote_Data["EUR"]["GBP"]=0.857552032
FX_Quote_Data["EUR"]["HRK"]=7.2940410016
FX_Quote_Data["EUR"]["NOK"]=7.84011
FX_Quote_Data["EUR"]["JPY"]=123.30684
FX_Quote_Data["JPY"]["EUR"]=0.0081098502
FX_Quote_Data["JPY"]["HRK"]=0.0565
FX_Quote_Data["JPY"]["SEK"]=0.071067

local graphFX = graph.NewGraph()

graphFX.setGraphMatrix(FX_Quote_Data)

local FXQuote = risk.newFXQuote()

FXQuote.setFXQuoteGraph(graphFX)

local flag, opt_quotes_graph, predecessorSet = FXQuote.getOptimizedFXQuote()
assert(flag == false)

print("\n-----------------------------------------------------")
print("Passed FXQuoteGraph unit tests!")
