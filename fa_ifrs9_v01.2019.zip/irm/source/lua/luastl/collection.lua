--[[
/* Copyright (C) 2015 SAS Institute Inc. Cary, NC, USA */

/*!
\file    collection.lua

\brief   This file is to store the Collection library which has all the functions declared. 

\ingroup commonAnalytics

\author  SAS Institute Inc.

\date    2015

\details This file first creates class: Collection,
         then declare all the functions:  NewStack NewSet newMinPriorityQueue

*/

]]

local collection={}


--[[
/*!
\function NewStack

\brief    push element to stack, pop out element from stack and check if stack is empty
       
\ingroup collection.lua

*/
]]
function collection.NewStack()
  
  --private data
  local self = {}
  
  -- push element to stack
  local push = function(...)
      for _, v in ipairs{...} do
        self[#self+1] = v
      end
  end

  -- pop out element from stack
  local  pop = function()      
      if 1 > #self then
        error("underflow in NewStack-created stack")
      end
      return table.remove(self)
  end
  
  -- check if stack is empty
  local  isEmpty = function()
      if #self == 0 then
        return true
      else
        return false
      end
  end
  
  return {
         pop = pop,
         push = push,
         isEmpty = isEmpty
         }
end

--[[
/*!
\function NewSet

\brief    Use hashed set from table
          
 \usage   Usage:
          mySet = collection.NewSet()
          assert(mySet.isEmpty() == true)
          mySet.insert(1)
          mySet.insert(2)
          mySet.remove(2)
          mySet.remove(4)
          assert(mySet.isEmpty() == false)
\ingroup collection.lua

*/
]]
function collection.NewSet()

  --private data
  local self = {
    --number of elements in set
    numElement = 0,
    hashedSet  = {}
  }
  
  --declare function
  local getNumElements
  local isContained
  local insert
  local remove
  local isEmpty
  local allElements
  local getElementValue
  
  getNumElements = function()
  
    return self.numElement
  
  end
  
  -- check if set contains element v 
  isContained = function(key)
    if self.hashedSet[key] ~= nil then
      return true
    else
      return false
    end
  end
  
  -- get value of element
  getElementValue = function(key)
    if not isContained(key) then
      
      return nil
      
    else
 
      return self.hashedSet[key]
    end
 
  end
  
  -- insert element in set
  insert = function(key, value)
  
    local _value
    if value == nil then
      _value = true 
    else
      _value = value
    end
    
    if(not isContained(key)) then
      self.numElement = self.numElement + 1
      self.hashedSet[key] = _value
    end
  end
  
  -- remove element from set
  remove = function(key)
    if (isContained(key)) then
      self.hashedSet[key] = nil
      self.numElement = self.numElement - 1
    end
  end
  
  -- check if set is empty
  isEmpty = function()
    if self.numElement == 0 then 
      return true
    else
      return false
    end
  end
  
  -- iterators
  allElements = function()

    return coroutine.wrap(
      function()
        local key
        for key, value in pairs(self.hashedSet) do
          coroutine.yield(key, value)
        end
      end)

  end
  
  return {
          isContained = isContained,
          insert = insert,
          remove = remove,
          isEmpty = isEmpty,
          allElements = allElements,
          getElementValue = getElementValue,
          getNumElements = getNumElements
          }
 
end

--[[
/*!
\function newMinPriorityQueue

\brief    min priority queue naive implementation
         
\ingroup collection.lua

*/
]]
function collection.newMinPriorityQueue()

  local self = {
                array = {},
                numElement = 0,
                keySet = collection.NewSet()
                }
                
  --check if min priority queue is empty
  local isEmpty = function()
    if self.numElement == 0 then 
      return true
    else
      return false
    end
  end
  
  -- insert element with priority
  -- when priority == nil, it means priority is infinity
  local insert = function(key, priority)
  
    if self.keySet.isContained(key) then
    
      error("Key: "..key.." already exists in min priority queue!")
      
    end
    
    self.keySet.insert(key)
    
    -- special case where priority is nil, 
    -- insert element to the last position of queue
    if priority == nil then
    
      -- move it to the last position of array
      table.insert(self.array, {key = key, priority = priority})
      
      self.numElement = self.numElement + 1
      
      return
      
    else
    
      local index, valuePair
      
      -- TODO: use binary search in future
            
      for index = 1, #self.array  do
        
        valuePair = self.array[index]
        
        if valuePair.priority == nil or valuePair.priority > priority then  
        
          table.insert(self.array, index, {key = key, priority = priority})  
          
          self.numElement = self.numElement + 1
          
          return
        
        end -- end of if valuePair.priority > priority then        
              
      end -- for index = 1, #self.array  do    
      
      --reach last position, insert element to the last
      
      table.insert(self.array, {key = key, priority = priority})
      
      self.numElement = self.numElement + 1
      
    end-- end of else if priority == nil then
    
        
  end
  
  --return the index of array for key
  local searchKeyForIndex = function(key)
  
    local i, valuePair, index
    
    for i, valuePair in ipairs(self.array) do
    
      if valuePair.key == key then
      
        index = i
        
        break
        
      end
      
    end
    
    return index
    
  end
  
  -- private function to remove element with key from min priority queue
  local remove = function(key)
  
    if not self.keySet.isContained(key) then
    
      error("Key: "..key.."doesn't exist. Failed to remove element with key: ".. key)
    
    end
    
    self.numElement = self.numElement - 1
    
    self.keySet.remove(key)    
    
    local index = searchKeyForIndex (key)
           
    table.remove(self.array, index)
    
  end
  
  --extract min priority element from queue
  local extractMin = function()
  
    if isEmpty() then
      
      error("Min priority queue is empty. Failed to extractMin.")
      
    end
  
    local valuePair = self.array[1]
    
    remove(valuePair.key)
    
    return valuePair.key, valuePair.priority
    
  end
  
  -- return min priority element
  local minElement = function()
    
    if isEmpty() then
     
      error("Min priority queue is empty. Failed to extractMin.")
    
    else
    
      return self.array[1].key, self.array[1].priority
    
    end  
  
  end
  
  -- decrease priority of element with new one
  local decreasePriority = function(key, newPriority)

    if not self.keySet.isContained(key) then
    
      error("Key :"..key.." doesn't exist in min priority queue!")
      
    end
    
    remove(key)
    
    insert(key, newPriority)
      
  end
  

  
  return {
          isEmpty = isEmpty,
          insert = insert,
          extractMin = extractMin,
          minElement = minElement,
          decreasePriority = decreasePriority
          }
          
end -- end of function newMinPriorityQueue

return collection
