local collection = require "luastl.collection"

-----------------------------------------------------------------------------
--
--  Unit test min priority queue 1
-----------------------------------------------------------------------------
--

local mpQueue = collection.newMinPriorityQueue()

assert(mpQueue.isEmpty() == true)

--(A)
mpQueue.insert("A", nil)

--(B,A)
mpQueue.insert("B", 3)

--should raise error exception

assert(pcall(mpQueue.insert,"B", 6) == false)

--(C,B,A)
mpQueue.insert("C",1) 

--(C,B,A,D)
mpQueue.insert("D",nil) 

--(C,B,E,A,D)
mpQueue.insert("E",5) 

local key, result = mpQueue.minElement()
assert( key == "C")
assert( result == 1)

mpQueue.extractMin()
--(B(3),E(5),A(nil),D(nil))
key, result = mpQueue.minElement()
assert( key == "B")
assert( result == 3)

--should raise error
assert(pcall(mpQueue.insert,"D", 6) == false)

mpQueue.decreasePriority("D", 2)
--(D(2),B(3),E(5),A(nil))

key, result = mpQueue.minElement() 
assert(key == "D")
assert(result == 2)

assert(mpQueue.isEmpty() == false)

mpQueue.decreasePriority("A", 4)
--(D(2),B(3),A(4),E(5))
key, result = mpQueue.minElement()
assert( key == "D")
assert( result == 2)

mpQueue.extractMin()
--(B(3),A(4),E(5))

key, result = mpQueue.minElement()
assert( key == "B")
assert( result == 3)

mpQueue.extractMin()
--(A(4),E(5))

key, result = mpQueue.minElement()
assert( key == "A")
assert( result == 4)

mpQueue.extractMin()
--(E(5))

key, result = mpQueue.minElement()
assert( key == "E")
assert( result == 5)

mpQueue.extractMin()
--()

assert(pcall(mpQueue.extractMin) == false)

assert(mpQueue.isEmpty() == true)

-----------------------------------------------------------------------------
--
--  Unit test min priority queue 2
-----------------------------------------------------------------------------
mpQueue = nil

mpQueue = collection.newMinPriorityQueue()

mpQueue.insert("A", 2)
--(A(2))
key, result = mpQueue.minElement()
assert( key == "A")
assert( result == 2)

mpQueue.insert("B", 1)
--(B(1), A(2))
key, result = mpQueue.minElement()
assert( key == "B")
assert( result == 1)


mpQueue.insert("C", 5)
--(B(1), A(2),C(5))
key, result = mpQueue.minElement()
assert( key == "B")
assert( result == 1)



mpQueue.insert("D", 7)
--(B(1), A(2),C(5), D(7))
key, result = mpQueue.minElement()
assert( key == "B")
assert( result == 1)


mpQueue.decreasePriority("C", 0)
--(C(0),B(1), A(2), D(7))
key, result = mpQueue.minElement()
assert( key == "C")
assert( result == 0)

mpQueue.insert("E", nil)
--(C(0),B(1), A(2), D(7),E(nil))
key, result = mpQueue.minElement()
assert( key == "C")
assert( result == 0)

mpQueue.extractMin()
--(B(1), A(2), D(7),E(nil))
key, result = mpQueue.minElement()
assert( key == "B")
assert( result == 1)

mpQueue.extractMin()
--(A(2), D(7),E(nil))
key, result = mpQueue.minElement()
assert( key == "A")
assert( result == 2)

mpQueue.extractMin()
--(D(7),E(nil))
key, result = mpQueue.minElement()
assert( key == "D")
assert( result == 7)

mpQueue.decreasePriority("E", 2)
--(E(2),D(7))
key, result = mpQueue.minElement()
assert( key == "E")
assert( result == 2)

mpQueue.extractMin()
--(D(7))
key, result = mpQueue.minElement()
assert( key == "D")
assert( result == 7)

mpQueue.extractMin()
assert(mpQueue.isEmpty() == true)

--should raise error
assert(pcall(mpQueue.extractMin) == false)

print("Passed min priority queue unit test!")