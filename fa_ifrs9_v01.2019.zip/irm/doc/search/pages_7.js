var searchData=
[
  ['reporting_20capabilities',['Reporting Capabilities',['../d1/d9d/200Reporting.html',1,'']]]
];
