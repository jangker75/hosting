var searchData=
[
  ['portfolio_20and_20counterparties',['Portfolio and counterparties',['../de/def/group__ddlFactPortfolio.html',1,'']]]
];
