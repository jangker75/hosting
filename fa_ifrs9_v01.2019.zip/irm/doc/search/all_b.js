var searchData=
[
  ['organizational_20setup',['Organizational setup',['../d7/d02/group__ddlFactEntity.html',1,'']]],
  ['other_20report_20tables',['Other report tables',['../d7/d48/group__ddlReportMartOther.html',1,'']]],
  ['other_20tables',['Other tables',['../d5/d7a/group__ddlStaticOther.html',1,'']]]
];
