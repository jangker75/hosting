var searchData=
[
  ['pairs',['pairs',['../d1/d18/risk_8lua.html#a782bf37dab1bfbe36f301c8951605741',1,'pairs(shortest_path) do FXQuote[vertex]:&#160;risk.lua'],['../d1/d18/risk_8lua.html#a22b8c6c57ba810edd4047db180c3c7e5',1,'pairs(shortest_path_matrix) do FXQuote[base_currency]:&#160;risk.lua']]]
];
