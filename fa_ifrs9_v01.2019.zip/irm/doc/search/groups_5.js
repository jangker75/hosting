var searchData=
[
  ['input_20data_20model',['Input Data Model',['../d5/df2/group__datamodel.html',1,'']]],
  ['in_2dmemory_20report_20tables',['In-memory report tables',['../d3/dde/group__ddlReportMart.html',1,'']]]
];
