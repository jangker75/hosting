var searchData=
[
  ['data_20quality_20tables',['Data Quality tables',['../d1/d6d/group__ddlStaticDQ.html',1,'']]]
];
