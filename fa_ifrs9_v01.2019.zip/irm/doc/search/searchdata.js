var indexSectionsWithContent =
{
  0: "abcdefgilmnopqrstuvw",
  1: "f",
  2: "abcdefgilmnpqrstuvw",
  3: "aelp",
  4: "cg",
  5: "abcdfimoprs",
  6: "abcdfiprs"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "groups",
  6: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Modules",
  6: "Pages"
};

